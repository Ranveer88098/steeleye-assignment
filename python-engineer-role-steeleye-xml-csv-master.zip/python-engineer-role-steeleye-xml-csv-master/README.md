# Extracting data from XML file and converting it into CSV file

## How to extract data from XML file and convert it into CSV file
- XML file is parsed using ElementTree
- All FinInstrmGnlAttrbts elements are found
- Loop over the FinInstrmGnlAttrbts elements and write the values to the CSV file
- Wrote number of rows to output.csv

